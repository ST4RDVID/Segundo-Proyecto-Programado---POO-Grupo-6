/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author st4rdvid
 */

import excepciones.DatoInvalidoException;
import java.time.LocalDate;
import java.time.LocalTime;

public class Evento {
    private String id;
    private String nombre;
    private LocalDate fecha;
    private LocalTime hora;
    private String descripcion;

    public Evento(String id, String nombre, LocalDate fecha, LocalTime hora, String descripcion)
            throws DatoInvalidoException {
        if (id == null || id.isBlank()) throw new DatoInvalidoException("El ID del evento es obligatorio.");
        if (nombre == null || nombre.isBlank()) throw new DatoInvalidoException("El nombre del evento es obligatorio.");
        if (fecha == null || hora == null) throw new DatoInvalidoException("Fecha y hora son obligatorias.");
        this.id = id.trim();
        this.nombre = nombre.trim();
        this.fecha = fecha;
        this.hora = hora;
        this.descripcion = (descripcion == null) ? "" : descripcion.trim();
    }

    public String getId() { return id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate fecha) { this.fecha = fecha; }
    public LocalTime getHora() { return hora; }
    public void setHora(LocalTime hora) { this.hora = hora; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    @Override
    public String toString() {
        return "[" + id + "] " + nombre + " - " + fecha + " " + hora + ": " + descripcion;
    }
}