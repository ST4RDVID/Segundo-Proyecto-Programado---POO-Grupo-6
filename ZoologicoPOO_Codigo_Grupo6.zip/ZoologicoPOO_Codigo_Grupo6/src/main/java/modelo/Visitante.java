/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author st4rdvid
 */

import excepciones.DatoInvalidoException;
import java.time.LocalDate;

public class Visitante {
    private String nombreCompleto;
    private int edad;
    private LocalDate fechaVisita;

    public Visitante(String nombreCompleto, int edad, LocalDate fechaVisita) throws DatoInvalidoException {
        if (nombreCompleto == null || nombreCompleto.isBlank()) {
            throw new DatoInvalidoException("El nombre completo del visitante es obligatorio.");
        }
        if (edad < 0) {
            throw new DatoInvalidoException("La edad del visitante no puede ser negativa.");
        }
        if (fechaVisita == null) {
            throw new DatoInvalidoException("La fecha de visita es obligatoria.");
        }
        this.nombreCompleto = nombreCompleto.trim();
        this.edad = edad;
        this.fechaVisita = fechaVisita;
    }

    public boolean esMenorDeEdad() {
        return edad <= 17;
    }

    public String getNombreCompleto() { return nombreCompleto; }
    public int getEdad() { return edad; }
    public LocalDate getFechaVisita() { return fechaVisita; }

    @Override
    public String toString() {
        String categoria = esMenorDeEdad() ? "Menor de edad" : "Adulto";
        return nombreCompleto + " (" + edad + " años - " + categoria + ") - " + fechaVisita;
    }
}
