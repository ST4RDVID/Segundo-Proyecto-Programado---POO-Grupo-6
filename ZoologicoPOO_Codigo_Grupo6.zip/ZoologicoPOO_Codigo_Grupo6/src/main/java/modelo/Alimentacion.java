/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author st4rdvid
 */

import excepciones.DatoInvalidoException;
import java.time.LocalTime;

public class Alimentacion {
    private Animal animal;
    private String tipoAlimento;
    private double porcion;
    private String periodicidad;
    private LocalTime hora;
    private String descripcion;

    public Alimentacion(Animal animal, String tipoAlimento, double porcion,
                        String periodicidad, LocalTime hora, String descripcion) throws DatoInvalidoException {
        if (animal == null) throw new DatoInvalidoException("Debe seleccionar un animal.");
        if (tipoAlimento == null || tipoAlimento.isBlank()) throw new DatoInvalidoException("Indique el tipo de alimento.");
        if (porcion <= 0) throw new DatoInvalidoException("La porción debe ser mayor a 0.");
        if (periodicidad == null || periodicidad.isBlank()) throw new DatoInvalidoException("Indique la periodicidad.");

        this.animal = animal;
        this.tipoAlimento = tipoAlimento.trim();
        this.porcion = porcion;
        this.periodicidad = periodicidad.trim();
        this.hora = hora;
        this.descripcion = (descripcion == null) ? "" : descripcion.trim();
    }

    public Animal getAnimal() { return animal; }
    public String getTipoAlimento() { return tipoAlimento; }
    public void setTipoAlimento(String tipoAlimento) { this.tipoAlimento = tipoAlimento; }
    public double getPorcion() { return porcion; }
    public void setPorcion(double porcion) { this.porcion = porcion; }
    public String getPeriodicidad() { return periodicidad; }
    public void setPeriodicidad(String periodicidad) { this.periodicidad = periodicidad; }
    public LocalTime getHora() { return hora; }
    public void setHora(LocalTime hora) { this.hora = hora; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    @Override
    public String toString() {
        return animal.getNombre() + " -> " + tipoAlimento + " (" + porcion + ", " + periodicidad + ", " + hora + ")";
    }
}