/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author st4rdvid
 */

import excepciones.CapacidadExcedidaException;
import excepciones.DatoInvalidoException;

public class Habitat {
    private String nombre;
    private String tipoAmbiente;
    private int capacidadMaxima;
    private Animal[][] distribucion;

    public Habitat(String nombre, String tipoAmbiente, int filas, int columnas) throws DatoInvalidoException {
        setNombre(nombre);
        setTipoAmbiente(tipoAmbiente);
        if (filas <= 0 || columnas <= 0) {
            throw new DatoInvalidoException("Las dimensiones de la matriz del hábitat deben ser mayores que 0.");
        }
        this.distribucion = new Animal[filas][columnas];
        this.capacidadMaxima = filas * columnas;
    }

    public void agregarAnimal(Animal animal, int fila, int columna)
            throws DatoInvalidoException, CapacidadExcedidaException {
        if (animal == null) {
            throw new DatoInvalidoException("El animal no puede ser nulo.");
        }
        validarCoordenadas(fila, columna);
        if (distribucion[fila][columna] != null) {
            throw new CapacidadExcedidaException("La posición [" + fila + "][" + columna + "] ya está ocupada.");
        }
        if (contarAnimales() >= capacidadMaxima) {
            throw new CapacidadExcedidaException("El hábitat " + nombre + " alcanzó su capacidad máxima.");
        }
        distribucion[fila][columna] = animal;
        animal.setHabitat(this);
    }

    public boolean retirarAnimal(Animal animal) {
        if (animal == null) return false;
        for (int i = 0; i < distribucion.length; i++) {
            for (int j = 0; j < distribucion[i].length; j++) {
                if (distribucion[i][j] == animal) {
                    distribucion[i][j] = null;
                    return true;
                }
            }
        }
        return false;
    }

    public int contarAnimales() {
        int total = 0;
        for (Animal[] fila : distribucion) {
            for (Animal a : fila) {
                if (a != null) total++;
            }
        }
        return total;
    }

    public Animal[][] consultarDistribucion() {
        return distribucion;
    }

    private void validarCoordenadas(int fila, int columna) throws DatoInvalidoException {
        if (fila < 0 || fila >= distribucion.length || columna < 0 || columna >= distribucion[0].length) {
            throw new DatoInvalidoException("Coordenadas fuera de rango en " + nombre + ".");
        }
    }

    public String getNombre() { return nombre; }

    public final void setNombre(String nombre) throws DatoInvalidoException {
        if (nombre == null || nombre.isBlank()) {
            throw new DatoInvalidoException("El nombre del hábitat es obligatorio.");
        }
        this.nombre = nombre.trim();
    }

    public String getTipoAmbiente() { return tipoAmbiente; }

    public final void setTipoAmbiente(String tipoAmbiente) throws DatoInvalidoException {
        if (tipoAmbiente == null || tipoAmbiente.isBlank()) {
            throw new DatoInvalidoException("El tipo de ambiente es obligatorio.");
        }
        this.tipoAmbiente = tipoAmbiente.trim();
    }

    public int getCapacidadMaxima() { return capacidadMaxima; }

    @Override
    public String toString() {
        return nombre + " [" + tipoAmbiente + "] (" + contarAnimales() + "/" + capacidadMaxima + ")";
    }
}