/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

/**
 *
 * @author st4rdvid
 */

import excepciones.CapacidadExcedidaException;
import excepciones.DatoInvalidoException;
import java.util.ArrayList;
import modelo.Animal;
import modelo.Habitat;

public class GestorAnimales {
    private final ArrayList<Animal> animales = new ArrayList<>();
    private final GestorAlimentacion gestorAlimentacion;

    public GestorAnimales(GestorAlimentacion gestorAlimentacion) {
        this.gestorAlimentacion = gestorAlimentacion;
    }

    public void registrarAnimal(Animal animal, Habitat habitat, int fila, int columna)
            throws DatoInvalidoException, CapacidadExcedidaException {
        if (habitat == null) {
            throw new DatoInvalidoException("Debe asignar un hábitat válido.");
        }
        habitat.agregarAnimal(animal, fila, columna);
        animales.add(animal);
    }

    public ArrayList<Animal> consultarAnimales() {
        return animales;
    }

    public Animal buscarPorNombre(String nombre) {
        for (Animal a : animales) {
            if (a.getNombre().equalsIgnoreCase(nombre)) {
                return a;
            }
        }
        return null;
    }

    public void actualizarAnimal(String nombreActual, String nuevoNombre, String nuevaEspecie, int nuevaEdad)
            throws DatoInvalidoException {
        Animal a = buscarPorNombre(nombreActual);
        if (a == null) {
            throw new DatoInvalidoException("No se encontró el animal '" + nombreActual + "'.");
        }
        a.setNombre(nuevoNombre);
        a.setEspecie(nuevaEspecie);
        a.setEdad(nuevaEdad);
    }

    public void eliminarAnimal(String nombre) throws DatoInvalidoException {
        Animal a = buscarPorNombre(nombre);
        if (a == null) {
            throw new DatoInvalidoException("No se encontró el animal '" + nombre + "'.");
        }
        if (a.getHabitat() != null) {
            a.getHabitat().retirarAnimal(a);
        }
        if (gestorAlimentacion != null) {
            gestorAlimentacion.eliminarPorAnimal(a);
        }
        animales.remove(a);
    }

    public ArrayList<String> listarPorHabitat(Habitat habitat) {
        ArrayList<String> resultado = new ArrayList<>();
        if (habitat == null) return resultado;
        Animal[][] matriz = habitat.consultarDistribucion();
        for (int f = 0; f < matriz.length; f++) {
            for (int c = 0; c < matriz[f].length; c++) {
                if (matriz[f][c] != null) {
                    resultado.add("[" + f + "," + c + "] -> " + matriz[f][c].toString());
                }
            }
        }
        return resultado;
    }
}
