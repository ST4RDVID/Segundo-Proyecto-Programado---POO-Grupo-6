/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

/**
 *
 * @author st4rdvid
 */

import excepciones.DatoInvalidoException;
import java.util.ArrayList;
import modelo.Alimentacion;
import modelo.Animal;

public class GestorAlimentacion {
    private final ArrayList<Alimentacion> registros = new ArrayList<>();

    public void registrarAlimentacion(Alimentacion a) throws DatoInvalidoException {
        if (a == null) throw new DatoInvalidoException("Registro de alimentación inválido.");
        registros.add(a);
    }

    public ArrayList<Alimentacion> consultarAlimentaciones() {
        return registros;
    }

    public void eliminarPorAnimal(Animal animal) {
        registros.removeIf(item -> item.getAnimal().equals(animal));
    }

    public void eliminarAlimentacion(int indice) throws DatoInvalidoException {
        if (indice < 0 || indice >= registros.size()) {
            throw new DatoInvalidoException("Seleccione un registro de alimentación válido.");
        }
        registros.remove(indice);
    }
}
