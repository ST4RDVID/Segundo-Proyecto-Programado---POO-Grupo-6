/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

/**
 *
 * @author st4rdvid
 */

import excepciones.DatoInvalidoException;
import java.util.ArrayList;
import java.util.HashMap;
import modelo.Evento;

public class GestorEventos {
    private final ArrayList<Evento> eventos = new ArrayList<>();
    private final HashMap<String, Evento> eventosPorId = new HashMap<>();

    public void registrarEvento(Evento evento) throws DatoInvalidoException {
        if (evento == null) throw new DatoInvalidoException("Evento inválido.");
        if (eventosPorId.containsKey(evento.getId())) {
            throw new DatoInvalidoException("Ya existe un evento con el ID " + evento.getId() + ".");
        }
        eventos.add(evento);
        eventosPorId.put(evento.getId(), evento);
    }

    public ArrayList<Evento> consultarEventos() {
        return eventos;
    }

    public Evento buscarPorId(String id) {
        return eventosPorId.get(id);
    }

    public void eliminarEvento(String id) throws DatoInvalidoException {
        Evento e = eventosPorId.remove(id);
        if (e == null) {
            throw new DatoInvalidoException("No se encontró el evento con ID " + id + ".");
        }
        eventos.remove(e);
    }
}