/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

/**
 *
 * @author st4rdvid
 */

import excepciones.DatoInvalidoException;
import java.time.LocalDate;
import java.util.ArrayList;
import modelo.Visitante;

public class GestorVisitantes {
    private final ArrayList<Visitante> visitantes = new ArrayList<>();

    public void registrarVisitante(Visitante v) throws DatoInvalidoException {
        if (v == null) throw new DatoInvalidoException("Visitante inválido.");
        visitantes.add(v);
    }

    public ArrayList<Visitante> consultarVisitantes() {
        return visitantes;
    }

    public ArrayList<Visitante> consultarPorFecha(LocalDate fecha) {
        ArrayList<Visitante> filtrados = new ArrayList<>();
        for (Visitante v : visitantes) {
            if (v.getFechaVisita().equals(fecha)) {
                filtrados.add(v);
            }
        }
        return filtrados;
    }

    public int contarMenoresPorFecha(LocalDate fecha) {
        int menores = 0;
        for (Visitante v : consultarPorFecha(fecha)) {
            if (v.esMenorDeEdad()) menores++;
        }
        return menores;
    }

    public int contarAdultosPorFecha(LocalDate fecha) {
        int adultos = 0;
        for (Visitante v : consultarPorFecha(fecha)) {
            if (!v.esMenorDeEdad()) adultos++;
        }
        return adultos;
    }

    public void eliminarVisitante(int indice) throws DatoInvalidoException {
        if (indice < 0 || indice >= visitantes.size()) {
            throw new DatoInvalidoException("Seleccione un visitante válido.");
        }
        visitantes.remove(indice);
    }
}
