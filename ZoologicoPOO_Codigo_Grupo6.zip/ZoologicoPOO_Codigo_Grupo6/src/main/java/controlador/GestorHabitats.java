/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

/**
 *
 * @author st4rdvid
 */

import excepciones.CapacidadExcedidaException;
import excepciones.DatoInvalidoException;
import java.util.ArrayList;
import java.util.HashMap;
import modelo.Habitat;

public class GestorHabitats {
    private final ArrayList<Habitat> habitats = new ArrayList<>();
    private final HashMap<String, Habitat> mapaPorNombre = new HashMap<>();

    public void registrarHabitat(Habitat habitat) throws DatoInvalidoException {
        if (habitat == null) {
            throw new DatoInvalidoException("Hábitat inválido.");
        }
        String clave = habitat.getNombre().toLowerCase();
        if (mapaPorNombre.containsKey(clave)) {
            throw new DatoInvalidoException("Ya existe un hábitat con ese nombre.");
        }
        habitats.add(habitat);
        mapaPorNombre.put(clave, habitat);
    }

    public ArrayList<Habitat> consultarHabitats() {
        return habitats;
    }

    public Habitat buscarPorNombre(String nombre) {
        if (nombre == null) return null;
        return mapaPorNombre.get(nombre.trim().toLowerCase());
    }

    public void actualizarHabitat(String nombreActual, String nuevoNombre, String nuevoAmbiente)
            throws DatoInvalidoException {
        Habitat h = buscarPorNombre(nombreActual);
        if (h == null) {
            throw new DatoInvalidoException("No se encontró el hábitat '" + nombreActual + "'.");
        }
        mapaPorNombre.remove(h.getNombre().toLowerCase());
        h.setNombre(nuevoNombre);
        h.setTipoAmbiente(nuevoAmbiente);
        mapaPorNombre.put(h.getNombre().toLowerCase(), h);
    }

    public void eliminarHabitat(String nombre) throws DatoInvalidoException, CapacidadExcedidaException {
        Habitat h = buscarPorNombre(nombre);
        if (h == null) {
            throw new DatoInvalidoException("No se encontró el hábitat a eliminar.");
        }
        if (h.contarAnimales() > 0) {
            throw new CapacidadExcedidaException("No se puede eliminar un hábitat que aún contiene animales.");
        }
        habitats.remove(h);
        mapaPorNombre.remove(h.getNombre().toLowerCase());
    }
}