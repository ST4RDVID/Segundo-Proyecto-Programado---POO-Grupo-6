/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

/**
 *
 * @author st4rdvid
 */

import controlador.Zoologico;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.time.LocalDate;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import modelo.Animal;
import modelo.Autenticacion;
import modelo.Habitat;
import modelo.Visitante;

public class MainFrame extends JFrame {
    private final Zoologico zoologico;

    public MainFrame(Zoologico zoologico) {
        this.zoologico = zoologico;
        setTitle("Zoológico POO - Sistema de Administración");
        setSize(850, 550);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Animales y Mapa", crearPanelAnimalesYMapa());
        tabs.addTab("Visitantes", crearPanelVisitantes());
        // Aquí puedes agregar pestañas para Hábitats, Alimentación y Eventos

        add(tabs, BorderLayout.CENTER);
    }

    private JPanel crearPanelAnimalesYMapa() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        JTextArea areaSalida = new JTextArea();
        areaSalida.setEditable(false);

        JPanel botones = new JPanel();
        JButton btnListarAnimales = new JButton("Listar Animales");
        JButton btnVerMapa = new JButton("Ver Mapa por Hábitat");

        btnListarAnimales.addActionListener(e -> {
            StringBuilder sb = new StringBuilder();
            for (Animal a : zoologico.getGestorAnimales().consultarAnimales()) {
                sb.append(a.toString()).append("\n");
            }
            areaSalida.setText(sb.toString());
        });

        btnVerMapa.addActionListener(e -> {
            StringBuilder sb = new StringBuilder();
            for (Habitat h : zoologico.getGestorHabitats().consultarHabitats()) {
                sb.append("=== ").append(h.getNombre()).append(" ===\n");
                Animal[][] m = h.consultarDistribucion();
                for (int f = 0; f < m.length; f++) {
                    for (int c = 0; c < m[f].length; c++) {
                        String celda = (m[f][c] != null) ? m[f][c].getNombre() : "[Vacío]";
                        sb.append(String.format("%-15s", celda));
                    }
                    sb.append("\n");
                }
                sb.append("\n");
            }
            areaSalida.setText(sb.toString());
        });

        botones.add(btnListarAnimales);
        botones.add(btnVerMapa);
        panel.add(botones, BorderLayout.NORTH);
        panel.add(new JScrollPane(areaSalida), BorderLayout.CENTER);
        return panel;
    }

    private JPanel crearPanelVisitantes() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        JTextArea area = new JTextArea();
        area.setEditable(false);

        JPanel superior = new JPanel();
        JTextField txtFecha = new JTextField(LocalDate.now().toString(), 12);
        JButton btnReporte = new JButton("Reporte por Fecha (AAAA-MM-DD)");

        btnReporte.addActionListener(e -> {
            try {
                LocalDate fecha = LocalDate.parse(txtFecha.getText().trim());
                var lista = zoologico.getGestorVisitantes().consultarPorFecha(fecha);
                int menores = zoologico.getGestorVisitantes().contarMenoresPorFecha(fecha);
                int adultos = zoologico.getGestorVisitantes().contarAdultosPorFecha(fecha);

                StringBuilder sb = new StringBuilder();
                sb.append("Fecha: ").append(fecha).append("\n");
                sb.append("Total accesos: ").append(lista.size())
                  .append(" | Menores (<=17): ").append(menores)
                  .append(" | Adultos (>=18): ").append(adultos).append("\n\n");
                for (Visitante v : lista) {
                    sb.append(" - ").append(v).append("\n");
                }
                area.setText(sb.toString());
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Formato de fecha inválido. Use AAAA-MM-DD.",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        superior.add(new JLabel("Fecha:"));
        superior.add(txtFecha);
        superior.add(btnReporte);

        panel.add(superior, BorderLayout.NORTH);
        panel.add(new JScrollPane(area), BorderLayout.CENTER);
        return panel;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Autenticacion auth = new Autenticacion("admin", "1234");
            JPanel loginPanel = new JPanel(new GridLayout(2, 2, 6, 6));
            JTextField txtUsuario = new JTextField();
            JPasswordField txtClave = new JPasswordField();
            loginPanel.add(new JLabel("Usuario:"));
            loginPanel.add(txtUsuario);
            loginPanel.add(new JLabel("Contraseña:"));
            loginPanel.add(txtClave);

            int opcion = JOptionPane.showConfirmDialog(null, loginPanel,
                    "Login - Zoológico POO", JOptionPane.OK_CANCEL_OPTION);
            if (opcion == JOptionPane.OK_OPTION
                    && auth.validarCredenciales(txtUsuario.getText(), new String(txtClave.getPassword()))) {
                Zoologico zoo = new Zoologico();
                new MainFrame(zoo).setVisible(true);
            } else if (opcion == JOptionPane.OK_OPTION) {
                JOptionPane.showMessageDialog(null, "Credenciales incorrectas.",
                        "Acceso denegado", JOptionPane.ERROR_MESSAGE);
            }
        });
    }
}