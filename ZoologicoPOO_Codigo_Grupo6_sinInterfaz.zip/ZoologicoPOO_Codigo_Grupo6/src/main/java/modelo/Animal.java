/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author st4rdvid
 */
import excepciones.DatoInvalidoException;

public abstract class Animal {
    private String nombre;
    private String especie;
    private int edad;
    private Habitat habitat;

    public Animal(String nombre, String especie, int edad, Habitat habitat) throws DatoInvalidoException {
        setNombre(nombre);
        setEspecie(especie);
        setEdad(edad);
        this.habitat = habitat;
    }

    public abstract String obtenerTipoDieta();

    public String getNombre() {
        return nombre;
    }

    public final void setNombre(String nombre) throws DatoInvalidoException {
        if (nombre == null || nombre.isBlank()) {
            throw new DatoInvalidoException("El nombre del animal no puede estar vacío.");
        }
        this.nombre = nombre.trim();
    }

    public String getEspecie() {
        return especie;
    }

    public final void setEspecie(String especie) throws DatoInvalidoException {
        if (especie == null || especie.isBlank()) {
            throw new DatoInvalidoException("La especie no puede estar vacía.");
        }
        this.especie = especie.trim();
    }

    public int getEdad() {
        return edad;
    }

    public final void setEdad(int edad) throws DatoInvalidoException {
        if (edad < 0) {
            throw new DatoInvalidoException("La edad no puede ser negativa.");
        }
        this.edad = edad;
    }

    public Habitat getHabitat() {
        return habitat;
    }

    public void setHabitat(Habitat habitat) {
        this.habitat = habitat;
    }

    @Override
    public String toString() {
        String nombreHabitat = (habitat != null) ? habitat.getNombre() : "Sin asignar";
        return nombre + " (" + especie + ", " + edad + " años, Dieta: " + obtenerTipoDieta()
                + ", Hábitat: " + nombreHabitat + ")";
    }
}