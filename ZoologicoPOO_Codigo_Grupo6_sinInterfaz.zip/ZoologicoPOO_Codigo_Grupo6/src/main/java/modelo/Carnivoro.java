/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author st4rdvid
 */

import excepciones.DatoInvalidoException;

public class Carnivoro extends Animal {
    public Carnivoro(String nombre, String especie, int edad, Habitat habitat) throws DatoInvalidoException {
        super(nombre, especie, edad, habitat);
    }

    @Override
    public String obtenerTipoDieta() {
        return "Carnívoro";
    }
}
