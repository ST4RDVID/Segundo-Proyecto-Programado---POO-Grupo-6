/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author st4rdvid
 */
public class Autenticacion {
    private final String usuario;
    private final String clave;

    public Autenticacion(String usuario, String clave) {
        this.usuario = usuario;
        this.clave = clave;
    }

    public boolean validarCredenciales(String usuarioIngresado, String claveIngresada) {
        return usuario.equals(usuarioIngresado) && clave.equals(claveIngresada);
    }
}
