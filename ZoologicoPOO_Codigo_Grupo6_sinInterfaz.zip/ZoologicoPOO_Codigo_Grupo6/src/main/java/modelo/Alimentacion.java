/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author st4rdvid
 */

import excepciones.DatoInvalidoException;
import java.time.LocalTime;

public class Alimentacion {
    private Animal animal;
    private String tipoAlimento;
    private double porcion;
    private String unidadMedida;
    private LocalTime horario;
    private String frecuencia;

    public Alimentacion(Animal animal, String tipoAlimento, double porcion,
                        String unidadMedida, LocalTime horario, String frecuencia)
            throws DatoInvalidoException {
        if (animal == null) throw new DatoInvalidoException("Animal obligatorio.");
        if (tipoAlimento == null || tipoAlimento.isBlank()) throw new DatoInvalidoException("Tipo de alimento obligatorio.");
        if (porcion <= 0) throw new DatoInvalidoException("La porción debe ser mayor a 0.");
        if (unidadMedida == null || unidadMedida.isBlank()) throw new DatoInvalidoException("Unidad de medida obligatoria.");
        if (horario == null) throw new DatoInvalidoException("Horario obligatorio.");
        if (frecuencia == null || frecuencia.isBlank()) throw new DatoInvalidoException("Frecuencia obligatoria.");

        this.animal = animal;
        this.tipoAlimento = tipoAlimento.trim();
        this.porcion = porcion;
        this.unidadMedida = unidadMedida.trim();
        this.horario = horario;
        this.frecuencia = frecuencia.trim();
    }

    public Animal getAnimal() { return animal; }
    public String getTipoAlimento() { return tipoAlimento; }
    public void setTipoAlimento(String tipoAlimento) { this.tipoAlimento = tipoAlimento; }
    public double getPorcion() { return porcion; }
    public void setPorcion(double porcion) { this.porcion = porcion; }
    public String getUnidadMedida() { return unidadMedida; }
    public void setUnidadMedida(String unidadMedida) { this.unidadMedida = unidadMedida; }
    public LocalTime getHorario() { return horario; }
    public void setHorario(LocalTime horario) { this.horario = horario; }
    public String getFrecuencia() { return frecuencia; }
    public void setFrecuencia(String frecuencia) { this.frecuencia = frecuencia; }

    @Override
    public String toString() {
        return animal.getNombre() + ": " + porcion + " " + unidadMedida + " de " + tipoAlimento
                + " (" + frecuencia + " a las " + horario + ")";
    }
}