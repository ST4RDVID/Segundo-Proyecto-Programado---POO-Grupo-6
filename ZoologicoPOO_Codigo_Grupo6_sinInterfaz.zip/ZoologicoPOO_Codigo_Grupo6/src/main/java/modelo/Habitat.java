 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package modelo;

/**
 *
 * @author st4rdvid
 */

import excepciones.CapacidadExcedidaException;
import excepciones.DatoInvalidoException;

public class Habitat {
    private String nombre;
    private String tipoAmbiente;
    private int capacidadMaxima;
    private Animal[][] distribucion;

    public Habitat(String nombre, String tipoAmbiente, int capacidadMaxima, int filas)
            throws DatoInvalidoException {
        setNombre(nombre);
        setTipoAmbiente(tipoAmbiente);
        int columnas = 0;
        if (filas <= 0 || columnas <= 0) {
            throw new DatoInvalidoException("Las filas y columnas deben ser mayores a 0.");
        }
        if (capacidadMaxima <= 0 || capacidadMaxima > filas * columnas) {
            throw new DatoInvalidoException("La capacidad máxima debe ser mayor a 0 y no superar filas * columnas.");
        }
        this.capacidadMaxima = capacidadMaxima;
        this.distribucion = new Animal[filas][columnas];
    }

    public void agregarAnimal(Animal animal, int fila, int columna)
            throws DatoInvalidoException, CapacidadExcedidaException {
        if (animal == null) {
            throw new DatoInvalidoException("El animal no puede ser nulo.");
        }
        validarCoordenadas(fila, columna);
        if (!hayEspacio()) {
            throw new CapacidadExcedidaException("El hábitat " + nombre + " ya alcanzó su capacidad máxima.");
        }
        if (distribucion[fila][columna] != null) {
            throw new CapacidadExcedidaException("La posición [" + fila + "][" + columna + "] ya está ocupada.");
        }
        distribucion[fila][columna] = animal;
        animal.setHabitat(this);
    }

    public void retirarAnimal(Animal animal) {
        if (animal == null) {
            return;
        }
        for (Animal[] distribucion1 : distribucion) {
            for (int j = 0; j < distribucion1.length; j++) {
                if (distribucion1[j] == animal) {
                    distribucion1[j] = null;
                    return;
                }
            }
        }
    }

    public boolean hayEspacio() {
        return contarAnimales() < capacidadMaxima;
    }

    public int contarAnimales() {
        int contador = 0;
        for (Animal[] fila : distribucion) {
            for (Animal a : fila) {
                if (a != null) {
                    contador++;
                }
            }
        }
        return contador;
    }

    public Animal[][] consultarDistribucion() {
        return distribucion;
    }

    private void validarCoordenadas(int fila, int columna) throws DatoInvalidoException {
        if (fila < 0 || fila >= distribucion.length || columna < 0 || columna >= distribucion[0].length) {
            throw new DatoInvalidoException("Las coordenadas [" + fila + "][" + columna + "] están fuera del hábitat.");
        }
    }

    public String getNombre() {
        return nombre;
    }

    public final void setNombre(String nombre) throws DatoInvalidoException {
        if (nombre == null || nombre.isBlank()) {
            throw new DatoInvalidoException("El nombre del hábitat es obligatorio.");
        }
        this.nombre = nombre.trim();
    }

    public String getTipoAmbiente() {
        return tipoAmbiente;
    }

    public final void setTipoAmbiente(String tipoAmbiente) throws DatoInvalidoException {
        if (tipoAmbiente == null || tipoAmbiente.isBlank()) {
            throw new DatoInvalidoException("El tipo de ambiente es obligatorio.");
        }
        this.tipoAmbiente = tipoAmbiente.trim();
    }

    public int getCapacidadMaxima() {
        return capacidadMaxima;
    }

    public void setCapacidadMaxima(int capacidadMaxima) throws DatoInvalidoException {
        if (capacidadMaxima <= 0 || capacidadMaxima > distribucion.length * distribucion[0].length) {
            throw new DatoInvalidoException("Capacidad máxima inválida para la matriz del hábitat.");
        }
        this.capacidadMaxima = capacidadMaxima;
    }

    @Override
    public String toString() {
        return nombre + " (" + tipoAmbiente + ") - " + contarAnimales() + "/" + capacidadMaxima;
    }
}