/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

/**
 *
 * @author st4rdvid
 */

import excepciones.DatoInvalidoException;
import java.time.LocalTime;
import java.util.ArrayList;
import modelo.Alimentacion;
import modelo.Animal;

public class GestorAlimentacion {
    private final ArrayList<Alimentacion> alimentaciones = new ArrayList<>();

    public GestorAlimentacion() {
    }

    public void registrarAlimentacion(Alimentacion alimentacion) throws DatoInvalidoException {
        if (alimentacion == null) throw new DatoInvalidoException("Alimentación inválida.");
        alimentaciones.add(alimentacion);
    }

    public ArrayList<Alimentacion> consultarAlimentaciones() {
        return alimentaciones;
    }

    public ArrayList<Alimentacion> consultarPorAnimal(Animal animal) {
        ArrayList<Alimentacion> resultado = new ArrayList<>();
        if (animal == null) return resultado;
        for (Alimentacion a : alimentaciones) {
            if (a.getAnimal().equals(animal)) {
                resultado.add(a);
            }
        }
        return resultado;
    }

    public void actualizarAlimentacion(Alimentacion alimentacion, String tipoAlimento, double porcion,
                                       String unidadMedida, LocalTime horario, String frecuencia)
            throws DatoInvalidoException {
        if (alimentacion == null) throw new DatoInvalidoException("Alimentación inválida.");
        if (tipoAlimento == null || tipoAlimento.isBlank()) throw new DatoInvalidoException("Tipo de alimento obligatorio.");
        if (porcion <= 0) throw new DatoInvalidoException("La porción debe ser mayor a 0.");
        alimentacion.setTipoAlimento(tipoAlimento.trim());
        alimentacion.setPorcion(porcion);
        alimentacion.setUnidadMedida(unidadMedida);
        alimentacion.setHorario(horario);
        alimentacion.setFrecuencia(frecuencia);
    }

    public void eliminarAlimentacion(Alimentacion alimentacion) throws DatoInvalidoException {
        if (alimentacion == null) throw new DatoInvalidoException("Alimentación inválida.");
        alimentaciones.remove(alimentacion);
    }

    public void eliminarPorAnimal(Animal animal) {
        if (animal == null) return;
        alimentaciones.removeIf(item -> item.getAnimal().equals(animal));
    }
}