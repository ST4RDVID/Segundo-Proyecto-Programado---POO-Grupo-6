/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

/**
 *
 * @author st4rdvid
 */

import excepciones.CapacidadExcedidaException;
import excepciones.DatoInvalidoException;
import java.util.ArrayList;
import modelo.Habitat;

public class GestorHabitats {
    private final ArrayList<Habitat> habitats = new ArrayList<>();

    public GestorHabitats() {
    }

    public void registrarHabitat(Habitat habitat) throws DatoInvalidoException {
        if (habitat == null) throw new DatoInvalidoException("Hábitat inválido.");
        habitats.add(habitat);
    }

    public ArrayList<Habitat> consultarHabitats() {
        return habitats;
    }

    public void actualizarHabitat(Habitat habitat, String nombre, String tipoAmbiente, int capacidadMaxima)
            throws DatoInvalidoException {
        if (habitat == null) throw new DatoInvalidoException("Hábitat inválido.");
        habitat.setNombre(nombre);
        habitat.setTipoAmbiente(tipoAmbiente);
        habitat.setCapacidadMaxima(capacidadMaxima);
    }

    public void eliminarHabitat(Habitat habitat) throws DatoInvalidoException, CapacidadExcedidaException {
        if (habitat == null) throw new DatoInvalidoException("Hábitat inválido.");
        if (habitat.contarAnimales() > 0) {
            throw new CapacidadExcedidaException("No se puede eliminar un hábitat con animales asignados.");
        }
        habitats.remove(habitat);
    }
}