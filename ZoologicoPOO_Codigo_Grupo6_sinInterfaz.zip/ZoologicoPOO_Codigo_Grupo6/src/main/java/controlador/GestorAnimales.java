/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

/**
 *
 * @author st4rdvid
 */

import excepciones.CapacidadExcedidaException;
import excepciones.DatoInvalidoException;
import java.util.ArrayList;
import modelo.Animal;
import modelo.Habitat;

public class GestorAnimales {
    private final ArrayList<Animal> animales = new ArrayList<>();
    private final GestorAlimentacion gestorAlimentacion;

    public GestorAnimales(GestorAlimentacion gestorAlimentacion) {
        this.gestorAlimentacion = gestorAlimentacion;
    }

    public void registrarAnimal(Animal animal, Habitat habitat, int fila, int columna)
            throws DatoInvalidoException, CapacidadExcedidaException {
        if (animal == null || habitat == null) {
            throw new DatoInvalidoException("Animal y hábitat son obligatorios.");
        }
        habitat.agregarAnimal(animal, fila, columna);
        if (!animales.contains(animal)) {
            animales.add(animal);
        }
    }

    public ArrayList<Animal> consultarAnimales() {
        return animales;
    }

    public void actualizarAnimal(Animal animal, String nombre, String especie, int edad)
            throws DatoInvalidoException {
        if (animal == null) throw new DatoInvalidoException("Animal inválido.");
        animal.setNombre(nombre);
        animal.setEspecie(especie);
        animal.setEdad(edad);
    }

    public void eliminarAnimal(Animal animal) throws DatoInvalidoException {
        if (animal == null) throw new DatoInvalidoException("Animal inválido.");
        if (animal.getHabitat() != null) {
            animal.getHabitat().retirarAnimal(animal);
        }
        if (gestorAlimentacion != null) {
            gestorAlimentacion.eliminarPorAnimal(animal);
        }
        animales.remove(animal);
    }

    public void trasladarAnimal(Animal animal, Habitat destino, int fila, int columna)
            throws DatoInvalidoException, CapacidadExcedidaException {
        if (animal == null || destino == null) {
            throw new DatoInvalidoException("Animal y hábitat destino son obligatorios.");
        }
        Habitat origen = animal.getHabitat();
        destino.agregarAnimal(animal, fila, columna);
        if (origen != null && origen != destino) {
            origen.retirarAnimal(animal);
        }
    }

    public ArrayList<Animal> consultarPorHabitat(Habitat habitat) {
        ArrayList<Animal> encontrados = new ArrayList<>();
        if (habitat == null) return encontrados;
        Animal[][] matriz = habitat.consultarDistribucion();
        for (Animal[] fila : matriz) {
            for (Animal a : fila) {
                if (a != null) {
                    encontrados.add(a);
                }
            }
        }
        return encontrados;
    }
}