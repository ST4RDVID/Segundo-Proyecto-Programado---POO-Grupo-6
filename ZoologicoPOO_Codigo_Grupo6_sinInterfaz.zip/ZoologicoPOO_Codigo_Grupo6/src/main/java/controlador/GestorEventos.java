/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

/**
 *
 * @author st4rdvid
 */

import excepciones.DatoInvalidoException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import modelo.Evento;

public class GestorEventos {
    private final ArrayList<Evento> eventos = new ArrayList<>();

    public GestorEventos() {
    }

    public void registrarEvento(Evento evento) throws DatoInvalidoException {
        if (evento == null) throw new DatoInvalidoException("Evento inválido.");
        eventos.add(evento);
    }

    public ArrayList<Evento> consultarEventos() {
        return eventos;
    }

    public void actualizarEvento(Evento evento, String nombre, LocalDate fecha, LocalTime hora, String descripcion)
            throws DatoInvalidoException {
        if (evento == null) throw new DatoInvalidoException("Evento inválido.");
        if (nombre == null || nombre.isBlank()) throw new DatoInvalidoException("Nombre obligatorio.");
        evento.setNombre(nombre.trim());
        evento.setFecha(fecha);
        evento.setHora(hora);
        evento.setDescripcion(descripcion);
    }

    public void eliminarEvento(Evento evento) throws DatoInvalidoException {
        if (evento == null) throw new DatoInvalidoException("Evento inválido.");
        eventos.remove(evento);
    }
}