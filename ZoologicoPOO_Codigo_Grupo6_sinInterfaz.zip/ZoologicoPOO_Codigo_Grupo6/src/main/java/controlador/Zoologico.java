/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

/**
 *
 * @author st4rdvid
 */

import excepciones.CapacidadExcedidaException;
import excepciones.DatoInvalidoException;
import java.time.LocalDate;
import java.time.LocalTime;
import modelo.Alimentacion;
import modelo.Carnivoro;
import modelo.Evento;
import modelo.Habitat;
import modelo.Herbivoro;
import modelo.Omnivoro;
import modelo.Visitante;

public class Zoologico {
    private final GestorHabitats gestorHabitats;
    private final GestorAlimentacion gestorAlimentacion;
    private final GestorAnimales gestorAnimales;
    private final GestorVisitantes gestorVisitantes;
    private final GestorEventos gestorEventos;

    public Zoologico() {
        this.gestorHabitats = new GestorHabitats();
        this.gestorAlimentacion = new GestorAlimentacion();
        this.gestorAnimales = new GestorAnimales(this.gestorAlimentacion);
        this.gestorVisitantes = new GestorVisitantes();
        this.gestorEventos = new GestorEventos();
        cargarDatosIniciales();
    }

    private void cargarDatosIniciales() {
        try {
            Habitat sabana = new Habitat("Sabana Africana", "Terrestre", 3, 3);
            Habitat selva = new Habitat("Selva Tropical", "Tropical", 3, 3);
            gestorHabitats.registrarHabitat(sabana);
            gestorHabitats.registrarHabitat(selva);

            Herbivoro jirafa = new Herbivoro("Melman", "Jirafa reticulada", 6, sabana);
            Carnivoro leon = new Carnivoro("Simba", "León africano", 5, sabana);
            Omnivoro oso = new Omnivoro("Baloo", "Oso pardo", 8, selva);

            gestorAnimales.registrarAnimal(jirafa, sabana, 0, 1);
            gestorAnimales.registrarAnimal(leon, sabana, 1, 2);
            gestorAnimales.registrarAnimal(oso, selva, 0, 0);

            gestorAlimentacion.registrarAlimentacion(
                    new Alimentacion(jirafa, "Follaje y heno", 12.5, "Diaria", LocalTime.of(8, 30), "Ración matutina"));
            gestorAlimentacion.registrarAlimentacion(
                    new Alimentacion(leon, "Carne de res", 8.0, "Diaria", LocalTime.of(14, 0), "Corte magro"));

            LocalDate hoy = LocalDate.now();
            gestorVisitantes.registrarVisitante(new Visitante("Ana Pérez", 24, hoy));
            gestorVisitantes.registrarVisitante(new Visitante("Mateo Rojas", 12, hoy));
            gestorVisitantes.registrarVisitante(new Visitante("Sofía Mora", 17, hoy));

            gestorEventos.registrarEvento(
                    new Evento("EV-01", "Charla de Conservación", hoy, LocalTime.of(10, 30), "Cuidado de fauna local"));
        } catch (DatoInvalidoException | CapacidadExcedidaException ex) {
            System.err.println("Error al precargar datos iniciales: " + ex.getMessage());
        }
    }

    public GestorHabitats getGestorHabitats() { return gestorHabitats; }
    public GestorAlimentacion getGestorAlimentacion() { return gestorAlimentacion; }
    public GestorAnimales getGestorAnimales() { return gestorAnimales; }
    public GestorVisitantes getGestorVisitantes() { return gestorVisitantes; }
    public GestorEventos getGestorEventos() { return gestorEventos; }
}
