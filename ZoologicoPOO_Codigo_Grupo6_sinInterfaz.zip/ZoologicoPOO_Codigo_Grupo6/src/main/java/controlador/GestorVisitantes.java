/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

/**
 *
 * @author st4rdvid
 */

import excepciones.DatoInvalidoException;
import java.time.LocalDate;
import java.util.ArrayList;
import modelo.Visitante;

public class GestorVisitantes {
    private final ArrayList<Visitante> visitantes = new ArrayList<>();

    public GestorVisitantes() {
    }

    public void registrarVisitante(Visitante visitante) throws DatoInvalidoException {
        if (visitante == null) throw new DatoInvalidoException("Visitante inválido.");
        visitantes.add(visitante);
    }

    public ArrayList<Visitante> consultarVisitantes() {
        return visitantes;
    }

    public void actualizarVisitante(Visitante visitante, String nombreCompleto, int edad, LocalDate fechaVisita)
            throws DatoInvalidoException {
        if (visitante == null) throw new DatoInvalidoException("Visitante inválido.");
        if (nombreCompleto == null || nombreCompleto.isBlank()) throw new DatoInvalidoException("Nombre obligatorio.");
        if (edad < 0) throw new DatoInvalidoException("Edad inválida.");
        if (fechaVisita == null) throw new DatoInvalidoException("Fecha obligatoria.");
        visitante.setNombreCompleto(nombreCompleto.trim());
        visitante.setEdad(edad);
        visitante.setFechaVisita(fechaVisita);
    }

    public void eliminarVisitante(Visitante visitante) throws DatoInvalidoException {
        if (visitante == null) throw new DatoInvalidoException("Visitante inválido.");
        visitantes.remove(visitante);
    }

    public ArrayList<Visitante> consultarVisitantesPorFecha(LocalDate fecha) {
        ArrayList<Visitante> resultado = new ArrayList<>();
        if (fecha == null) return resultado;
        for (Visitante v : visitantes) {
            if (fecha.equals(v.getFechaVisita())) {
                resultado.add(v);
            }
        }
        return resultado;
    }

    public int contarVisitantesPorFecha(LocalDate fecha) {
        return consultarVisitantesPorFecha(fecha).size();
    }

    public int contarMenoresPorFecha(LocalDate fecha) {
        int menores = 0;
        for (Visitante v : consultarVisitantesPorFecha(fecha)) {
            if (v.esMenorDeEdad()) menores++;
        }
        return menores;
    }

    public int contarAdultosPorFecha(LocalDate fecha) {
        int adultos = 0;
        for (Visitante v : consultarVisitantesPorFecha(fecha)) {
            if (!v.esMenorDeEdad()) adultos++;
        }
        return adultos;
    }
}